# 🎬 Visual Novel Art & Motion Prompt Catalog

> Generated **30** production-grade prompts for Overtime Secrets.
> Ready for ComfyUI on Apple Silicon Mac M4 Pro.

| ID | Category | Heroine | Title | Resolution | Target Model |
|---|---|---|---|---|---|
| `noey_sprite_normal` | sprite | noey | น้องเนย (Noey) - Expression: normal | 832x1216 (Portrait) | SDXL / Illustrious / Animagine |
| `noey_sprite_blush` | sprite | noey | น้องเนย (Noey) - Expression: blush | 832x1216 (Portrait) | SDXL / Illustrious / Animagine |
| `noey_sprite_panicked` | sprite | noey | น้องเนย (Noey) - Expression: panicked | 832x1216 (Portrait) | SDXL / Illustrious / Animagine |
| `noey_sprite_pout` | sprite | noey | น้องเนย (Noey) - Expression: pout | 832x1216 (Portrait) | SDXL / Illustrious / Animagine |
| `pim_sprite_strict` | sprite | pim | คุณพิมพ์ (Pim) - Expression: strict | 832x1216 (Portrait) | SDXL / Illustrious / Animagine |
| `pim_sprite_shocked` | sprite | pim | คุณพิมพ์ (Pim) - Expression: shocked | 832x1216 (Portrait) | SDXL / Illustrious / Animagine |
| `pim_sprite_seductive_blush` | sprite | pim | คุณพิมพ์ (Pim) - Expression: seductive_blush | 832x1216 (Portrait) | SDXL / Illustrious / Animagine |
| `pim_sprite_gentle_tease` | sprite | pim | คุณพิมพ์ (Pim) - Expression: gentle_tease | 832x1216 (Portrait) | SDXL / Illustrious / Animagine |
| `rinda_sprite_calculating` | sprite | rinda | คุณรินดา (Rinda) - Expression: calculating | 832x1216 (Portrait) | SDXL / Illustrious / Animagine |
| `rinda_sprite_interrogating` | sprite | rinda | คุณรินดา (Rinda) - Expression: interrogating | 832x1216 (Portrait) | SDXL / Illustrious / Animagine |
| `rinda_sprite_vulnerable` | sprite | rinda | คุณรินดา (Rinda) - Expression: vulnerable | 832x1216 (Portrait) | SDXL / Illustrious / Animagine |
| `rinda_sprite_relieved` | sprite | rinda | คุณรินดา (Rinda) - Expression: relieved | 832x1216 (Portrait) | SDXL / Illustrious / Animagine |
| `meena_sprite_poker_face` | sprite | meena | คุณมีนา (Meena) - Expression: poker_face | 832x1216 (Portrait) | SDXL / Illustrious / Animagine |
| `meena_sprite_suspicious` | sprite | meena | คุณมีนา (Meena) - Expression: suspicious | 832x1216 (Portrait) | SDXL / Illustrious / Animagine |
| `meena_sprite_wistful_secret` | sprite | meena | คุณมีนา (Meena) - Expression: wistful_secret | 832x1216 (Portrait) | SDXL / Illustrious / Animagine |
| `meena_sprite_intimate` | sprite | meena | คุณมีนา (Meena) - Expression: intimate | 832x1216 (Portrait) | SDXL / Illustrious / Animagine |
| `rhea_sprite_cold_contempt` | sprite | rhea | คุณหนู เร-อา (Rhea) - Expression: cold_contempt | 832x1216 (Portrait) | SDXL / Illustrious / Animagine |
| `rhea_sprite_intrigued_smirk` | sprite | rhea | คุณหนู เร-อา (Rhea) - Expression: intrigued_smirk | 832x1216 (Portrait) | SDXL / Illustrious / Animagine |
| `rhea_sprite_broken_ice` | sprite | rhea | คุณหนู เร-อา (Rhea) - Expression: broken_ice | 832x1216 (Portrait) | SDXL / Illustrious / Animagine |
| `rhea_sprite_queenly_grace` | sprite | rhea | คุณหนู เร-อา (Rhea) - Expression: queenly_grace | 832x1216 (Portrait) | SDXL / Illustrious / Animagine |
| `noey_event_cg` | event_cg | noey | น้องเนย (Noey) - Event CG: Under the Desk Romance | 1344x768 (16:9 Cinematic) | SDXL / Illustrious / Pony |
| `pim_event_cg` | event_cg | pim | คุณพิมพ์ (Pim) - Event CG: The Secret HR Cosplay Exposure | 1344x768 (16:9 Cinematic) | SDXL / Illustrious / Pony |
| `rinda_event_cg` | event_cg | rinda | คุณรินดา (Rinda) - Event CG: The Audit Interrogation | 1344x768 (16:9 Cinematic) | SDXL / Illustrious / Pony |
| `meena_event_cg` | event_cg | meena | คุณมีนา (Meena) - Event CG: Executive Limousine Secrets | 1344x768 (16:9 Cinematic) | SDXL / Illustrious / Pony |
| `rhea_event_cg` | event_cg | rhea | คุณหนู เร-อา (Rhea) - Event CG: The Penthouse Storm Climax | 1344x768 (16:9 Cinematic) | SDXL / Illustrious / Pony |
| `noey_motion_ltx` | motion_cg | noey | น้องเนย (Noey) - Motion CG: Noey Desk Romance Motion (5s) | 1280x720 (16:9 Video @ 24fps) | LTX-Video 2.5 Distilled GGUF |
| `pim_motion_ltx` | motion_cg | pim | คุณพิมพ์ (Pim) - Motion CG: Pim HR Archive Confrontation (5s) | 1280x720 (16:9 Video @ 24fps) | LTX-Video 2.5 Distilled GGUF |
| `rinda_motion_ltx` | motion_cg | rinda | คุณรินดา (Rinda) - Motion CG: Rinda Audit Interrogation Motion (5s) | 1280x720 (16:9 Video @ 24fps) | LTX-Video 2.5 Distilled GGUF |
| `meena_motion_ltx` | motion_cg | meena | คุณมีนา (Meena) - Motion CG: Meena Limousine Night Drive (6s) | 1280x720 (16:9 Video @ 24fps) | LTX-Video 2.5 Distilled GGUF |
| `rhea_motion_ltx` | motion_cg | rhea | คุณหนู เร-อา (Rhea) - Motion CG: Rhea Penthouse Storm Climax Motion (6s) | 1280x720 (16:9 Video @ 24fps) | LTX-Video 2.5 Distilled GGUF |

---

## Prompt Details

### 📌 `noey_sprite_normal`: น้องเนย (Noey) - Expression: normal
- **Category:** `sprite`
- **Model:** `SDXL / Illustrious / Animagine`
- **Resolution:** `832x1216 (Portrait)`

```text
1girl, noey_intern, solo, 21 years old, cute asian anime girl, caramel brown hair, side ponytail with pink scrunchie, bright magenta eyes, white office blouse, pink ribbon tie, navy blue pleated skirt, gentle smile, looking at viewer, open happy eyes, transparent background, upper body, masterpiece, best quality, ultra-detailed, 8k wallpaper, aesthetic, dynamic lighting, finely detailed anime eyes, studio lighting
```

### 📌 `noey_sprite_blush`: น้องเนย (Noey) - Expression: blush
- **Category:** `sprite`
- **Model:** `SDXL / Illustrious / Animagine`
- **Resolution:** `832x1216 (Portrait)`

```text
1girl, noey_intern, solo, 21 years old, cute asian anime girl, caramel brown hair, side ponytail with pink scrunchie, bright magenta eyes, white office blouse, pink ribbon tie, navy blue pleated skirt, heavy blushing, watery eyes, embarrassment, shy o-shaped mouth, cute flustered expression, transparent background, upper body, masterpiece, best quality, ultra-detailed, 8k wallpaper, aesthetic, dynamic lighting, finely detailed anime eyes, studio lighting
```

### 📌 `noey_sprite_panicked`: น้องเนย (Noey) - Expression: panicked
- **Category:** `sprite`
- **Model:** `SDXL / Illustrious / Animagine`
- **Resolution:** `832x1216 (Portrait)`

```text
1girl, noey_intern, solo, 21 years old, cute asian anime girl, caramel brown hair, side ponytail with pink scrunchie, bright magenta eyes, white office blouse, pink ribbon tie, navy blue pleated skirt, worried eyebrows, teary eyes, slightly parted lips, looking down nervously, transparent background, upper body, masterpiece, best quality, ultra-detailed, 8k wallpaper, aesthetic, dynamic lighting, finely detailed anime eyes, studio lighting
```

### 📌 `noey_sprite_pout`: น้องเนย (Noey) - Expression: pout
- **Category:** `sprite`
- **Model:** `SDXL / Illustrious / Animagine`
- **Resolution:** `832x1216 (Portrait)`

```text
1girl, noey_intern, solo, 21 years old, cute asian anime girl, caramel brown hair, side ponytail with pink scrunchie, bright magenta eyes, white office blouse, pink ribbon tie, navy blue pleated skirt, pouting puffed cheeks, looking sideways, slightly furrowed cute brows, transparent background, upper body, masterpiece, best quality, ultra-detailed, 8k wallpaper, aesthetic, dynamic lighting, finely detailed anime eyes, studio lighting
```

### 📌 `pim_sprite_strict`: คุณพิมพ์ (Pim) - Expression: strict
- **Category:** `sprite`
- **Model:** `SDXL / Illustrious / Animagine`
- **Resolution:** `832x1216 (Portrait)`

```text
1girl, pim_hr, solo, 30 years old, beautiful mature woman, sleek black hair in elegant updo, red-framed glasses, sharp violet eyes, voluptuous figure, dark navy tailored business blazer, tight white button-up shirt, navy pencil skirt, cleavage peek, condescending gaze, stern look, frowning, hand adjusting glasses, authoritative, transparent background, upper body, masterpiece, best quality, ultra-detailed, 8k wallpaper, aesthetic, dynamic lighting, finely detailed anime eyes, studio lighting
```

### 📌 `pim_sprite_shocked`: คุณพิมพ์ (Pim) - Expression: shocked
- **Category:** `sprite`
- **Model:** `SDXL / Illustrious / Animagine`
- **Resolution:** `832x1216 (Portrait)`

```text
1girl, pim_hr, solo, 30 years old, beautiful mature woman, sleek black hair in elegant updo, red-framed glasses, sharp violet eyes, voluptuous figure, dark navy tailored business blazer, tight white button-up shirt, navy pencil skirt, cleavage peek, eyes wide in shock, glasses slipping down nose, flushed cheeks, gasp mouth, disheveled composure, transparent background, upper body, masterpiece, best quality, ultra-detailed, 8k wallpaper, aesthetic, dynamic lighting, finely detailed anime eyes, studio lighting
```

### 📌 `pim_sprite_seductive_blush`: คุณพิมพ์ (Pim) - Expression: seductive_blush
- **Category:** `sprite`
- **Model:** `SDXL / Illustrious / Animagine`
- **Resolution:** `832x1216 (Portrait)`

```text
1girl, pim_hr, solo, 30 years old, beautiful mature woman, sleek black hair in elegant updo, red-framed glasses, sharp violet eyes, voluptuous figure, dark navy tailored business blazer, tight white button-up shirt, navy pencil skirt, cleavage peek, heavy blush, trembling lips, removing glasses, seductive flustered gaze, looking away in embarrassment, transparent background, upper body, masterpiece, best quality, ultra-detailed, 8k wallpaper, aesthetic, dynamic lighting, finely detailed anime eyes, studio lighting
```

### 📌 `pim_sprite_gentle_tease`: คุณพิมพ์ (Pim) - Expression: gentle_tease
- **Category:** `sprite`
- **Model:** `SDXL / Illustrious / Animagine`
- **Resolution:** `832x1216 (Portrait)`

```text
1girl, pim_hr, solo, 30 years old, beautiful mature woman, sleek black hair in elegant updo, red-framed glasses, sharp violet eyes, voluptuous figure, dark navy tailored business blazer, tight white button-up shirt, navy pencil skirt, cleavage peek, smirking playfully, raised eyebrow, looking over the rim of red glasses, transparent background, upper body, masterpiece, best quality, ultra-detailed, 8k wallpaper, aesthetic, dynamic lighting, finely detailed anime eyes, studio lighting
```

### 📌 `rinda_sprite_calculating`: คุณรินดา (Rinda) - Expression: calculating
- **Category:** `sprite`
- **Model:** `SDXL / Illustrious / Animagine`
- **Resolution:** `832x1216 (Portrait)`

```text
1girl, rinda_audit, solo, 28 years old, chic intelligent woman, dark brown bob cut hair, sharp amber golden eyes, slender long legs, formal charcoal grey waistcoat, white collared shirt with rolled up sleeves, silver pendant necklace, smirking confidently, piercing amber eyes, tilting head slightly, analytical gaze, transparent background, upper body, masterpiece, best quality, ultra-detailed, 8k wallpaper, aesthetic, dynamic lighting, finely detailed anime eyes, studio lighting
```

### 📌 `rinda_sprite_interrogating`: คุณรินดา (Rinda) - Expression: interrogating
- **Category:** `sprite`
- **Model:** `SDXL / Illustrious / Animagine`
- **Resolution:** `832x1216 (Portrait)`

```text
1girl, rinda_audit, solo, 28 years old, chic intelligent woman, dark brown bob cut hair, sharp amber golden eyes, slender long legs, formal charcoal grey waistcoat, white collared shirt with rolled up sleeves, silver pendant necklace, narrowed eyes, intense scrutiny, furrowed brow, pointing pen forward, stern professional pressure, transparent background, upper body, masterpiece, best quality, ultra-detailed, 8k wallpaper, aesthetic, dynamic lighting, finely detailed anime eyes, studio lighting
```

### 📌 `rinda_sprite_vulnerable`: คุณรินดา (Rinda) - Expression: vulnerable
- **Category:** `sprite`
- **Model:** `SDXL / Illustrious / Animagine`
- **Resolution:** `832x1216 (Portrait)`

```text
1girl, rinda_audit, solo, 28 years old, chic intelligent woman, dark brown bob cut hair, sharp amber golden eyes, slender long legs, formal charcoal grey waistcoat, white collared shirt with rolled up sleeves, silver pendant necklace, subtle blush on cheekbones, surprised wide eyes, loosened necktie, looking down caught off-guard, transparent background, upper body, masterpiece, best quality, ultra-detailed, 8k wallpaper, aesthetic, dynamic lighting, finely detailed anime eyes, studio lighting
```

### 📌 `rinda_sprite_relieved`: คุณรินดา (Rinda) - Expression: relieved
- **Category:** `sprite`
- **Model:** `SDXL / Illustrious / Animagine`
- **Resolution:** `832x1216 (Portrait)`

```text
1girl, rinda_audit, solo, 28 years old, chic intelligent woman, dark brown bob cut hair, sharp amber golden eyes, slender long legs, formal charcoal grey waistcoat, white collared shirt with rolled up sleeves, silver pendant necklace, soft affectionate smile, eyes gently closed, relaxed posture, exhaling softly, transparent background, upper body, masterpiece, best quality, ultra-detailed, 8k wallpaper, aesthetic, dynamic lighting, finely detailed anime eyes, studio lighting
```

### 📌 `meena_sprite_poker_face`: คุณมีนา (Meena) - Expression: poker_face
- **Category:** `sprite`
- **Model:** `SDXL / Illustrious / Animagine`
- **Resolution:** `832x1216 (Portrait)`

```text
1girl, meena_secretary, solo, 26 years old, gorgeous executive secretary, wavy chocolate brown long hair, calm hazel eyes, seductive elegance, beige tailored double-breasted suit, silk camisole, holding leather folder, serene gentle smile, closed lips, polite distant gaze, unreadable professional mask, transparent background, upper body, masterpiece, best quality, ultra-detailed, 8k wallpaper, aesthetic, dynamic lighting, finely detailed anime eyes, studio lighting
```

### 📌 `meena_sprite_suspicious`: คุณมีนา (Meena) - Expression: suspicious
- **Category:** `sprite`
- **Model:** `SDXL / Illustrious / Animagine`
- **Resolution:** `832x1216 (Portrait)`

```text
1girl, meena_secretary, solo, 26 years old, gorgeous executive secretary, wavy chocolate brown long hair, calm hazel eyes, seductive elegance, beige tailored double-breasted suit, silk camisole, holding leather folder, cold piercing stare, flat expression, tilting chin down, dangerous quiet intensity, transparent background, upper body, masterpiece, best quality, ultra-detailed, 8k wallpaper, aesthetic, dynamic lighting, finely detailed anime eyes, studio lighting
```

### 📌 `meena_sprite_wistful_secret`: คุณมีนา (Meena) - Expression: wistful_secret
- **Category:** `sprite`
- **Model:** `SDXL / Illustrious / Animagine`
- **Resolution:** `832x1216 (Portrait)`

```text
1girl, meena_secretary, solo, 26 years old, gorgeous executive secretary, wavy chocolate brown long hair, calm hazel eyes, seductive elegance, beige tailored double-breasted suit, silk camisole, holding leather folder, eyes looking out window wistfully, melancholic gentle expression, soft parted lips, resting cheek on hand, transparent background, upper body, masterpiece, best quality, ultra-detailed, 8k wallpaper, aesthetic, dynamic lighting, finely detailed anime eyes, studio lighting
```

### 📌 `meena_sprite_intimate`: คุณมีนา (Meena) - Expression: intimate
- **Category:** `sprite`
- **Model:** `SDXL / Illustrious / Animagine`
- **Resolution:** `832x1216 (Portrait)`

```text
1girl, meena_secretary, solo, 26 years old, gorgeous executive secretary, wavy chocolate brown long hair, calm hazel eyes, seductive elegance, beige tailored double-breasted suit, silk camisole, holding leather folder, tender flushed smile, eyelashes fluttering, soft warm gaze, loosened hair strands, transparent background, upper body, masterpiece, best quality, ultra-detailed, 8k wallpaper, aesthetic, dynamic lighting, finely detailed anime eyes, studio lighting
```

### 📌 `rhea_sprite_cold_contempt`: คุณหนู เร-อา (Rhea) - Expression: cold_contempt
- **Category:** `sprite`
- **Model:** `SDXL / Illustrious / Animagine`
- **Resolution:** `832x1216 (Portrait)`

```text
1girl, rhea_heiress, solo, 24 years old, stunning cool beauty, pale porcelain skin, long flowing obsidian raven hair with silver highlights, piercing icy blue eyes, aristocratic aura, high-end bespoke black designer suit, silk collar, minimalist diamond necklace, narrowed cold eyes, unimpressed glare, looking down at viewer, aloof stoic face, transparent background, upper body, masterpiece, best quality, ultra-detailed, 8k wallpaper, aesthetic, dynamic lighting, finely detailed anime eyes, studio lighting
```

### 📌 `rhea_sprite_intrigued_smirk`: คุณหนู เร-อา (Rhea) - Expression: intrigued_smirk
- **Category:** `sprite`
- **Model:** `SDXL / Illustrious / Animagine`
- **Resolution:** `832x1216 (Portrait)`

```text
1girl, rhea_heiress, solo, 24 years old, stunning cool beauty, pale porcelain skin, long flowing obsidian raven hair with silver highlights, piercing icy blue eyes, aristocratic aura, high-end bespoke black designer suit, silk collar, minimalist diamond necklace, subtle faint smirk, calculating sharp gaze, tilting chin up, predatory intelligence, transparent background, upper body, masterpiece, best quality, ultra-detailed, 8k wallpaper, aesthetic, dynamic lighting, finely detailed anime eyes, studio lighting
```

### 📌 `rhea_sprite_broken_ice`: คุณหนู เร-อา (Rhea) - Expression: broken_ice
- **Category:** `sprite`
- **Model:** `SDXL / Illustrious / Animagine`
- **Resolution:** `832x1216 (Portrait)`

```text
1girl, rhea_heiress, solo, 24 years old, stunning cool beauty, pale porcelain skin, long flowing obsidian raven hair with silver highlights, piercing icy blue eyes, aristocratic aura, high-end bespoke black designer suit, silk collar, minimalist diamond necklace, intense red blush covering pale cheeks, trembling dilated blue eyes, biting lower lip, breathless expression, loosened black tie, vulnerable beauty, transparent background, upper body, masterpiece, best quality, ultra-detailed, 8k wallpaper, aesthetic, dynamic lighting, finely detailed anime eyes, studio lighting
```

### 📌 `rhea_sprite_queenly_grace`: คุณหนู เร-อา (Rhea) - Expression: queenly_grace
- **Category:** `sprite`
- **Model:** `SDXL / Illustrious / Animagine`
- **Resolution:** `832x1216 (Portrait)`

```text
1girl, rhea_heiress, solo, 24 years old, stunning cool beauty, pale porcelain skin, long flowing obsidian raven hair with silver highlights, piercing icy blue eyes, aristocratic aura, high-end bespoke black designer suit, silk collar, minimalist diamond necklace, regal upright posture, calm commanding gaze, slight authoritative tilt of head, transparent background, upper body, masterpiece, best quality, ultra-detailed, 8k wallpaper, aesthetic, dynamic lighting, finely detailed anime eyes, studio lighting
```

### 📌 `noey_event_cg`: น้องเนย (Noey) - Event CG: Under the Desk Romance
- **Category:** `event_cg`
- **Model:** `SDXL / Illustrious / Pony`
- **Resolution:** `1344x768 (16:9 Cinematic)`

```text
masterpiece, 1girl, 1boy, noey_intern, close distance, intimate proximity under office wooden desk, soft warm shadows, dim office night lighting, girl crouching close to viewer, flushed red cheeks, nervous trembling breath, sweating slightly, messy brown side ponytail, slightly rumpled white blouse, shallow depth of field, cinematic lighting, sensual tension, ecchi romance aesthetic
```

### 📌 `pim_event_cg`: คุณพิมพ์ (Pim) - Event CG: The Secret HR Cosplay Exposure
- **Category:** `event_cg`
- **Model:** `SDXL / Illustrious / Pony`
- **Resolution:** `1344x768 (16:9 Cinematic)`

```text
masterpiece, 1girl, 1boy, pim_hr, locked HR records archive room late at night, dim moody neon street reflections through venetian blinds, girl backed against tall filing cabinets, caught red-handed in partially unzipped glamorous cosplay outfit under formal blazer, glasses askew on flushed cheeks, breathless expression of scandal and desperate surrender, cinematic depth of field, moody noir illumination
```

### 📌 `rinda_event_cg`: คุณรินดา (Rinda) - Event CG: The Audit Interrogation
- **Category:** `event_cg`
- **Model:** `SDXL / Illustrious / Pony`
- **Resolution:** `1344x768 (16:9 Cinematic)`

```text
masterpiece, 1girl, 1boy, rinda_audit, late night audit department, desks piled with confidential financial binders, harsh desk lamp beam cutting through room darkness, girl leaning across wooden conference table close to boy, charcoal waistcoat unbuttoned, amber eyes glowing in directional lamplight, predatory whisper distance, intense psychological suspense, cinematic noir lighting
```

### 📌 `meena_event_cg`: คุณมีนา (Meena) - Event CG: Executive Limousine Secrets
- **Category:** `event_cg`
- **Model:** `SDXL / Illustrious / Pony`
- **Resolution:** `1344x768 (16:9 Cinematic)`

```text
masterpiece, 1girl, 1boy, meena_secretary, luxury black executive limousine backseat, neon rain reflections gliding over tinted windows, streetlights flashing intermittently inside cabin, girl seated close to boy on leather upholstery, beige suit jacket draped over shoulders, quiet secretive whispers, hazel eyes illuminated by passing neon billboards, cinematic bokeh, luxurious intimate atmosphere
```

### 📌 `rhea_event_cg`: คุณหนู เร-อา (Rhea) - Event CG: The Penthouse Storm Climax
- **Category:** `event_cg`
- **Model:** `SDXL / Illustrious / Pony`
- **Resolution:** `1344x768 (16:9 Cinematic)`

```text
masterpiece, 1girl, 1boy, rhea_heiress, penthouse office top floor at midnight, giant panoramic glass window with raging rainstorm and lightning flashing outside, luxury executive leather chair, dim ambient amber room lights, girl seated with wet disheveled black suit, tie pulled loose, chest heaving slightly, flushed pale skin, looking up at boy with breathtaking mixture of pride and passionate surrender, sensual lighting, cinematic masterpiece, 8k resolution, romantic tension
```

### 📌 `noey_motion_ltx`: น้องเนย (Noey) - Motion CG: Noey Desk Romance Motion (5s)
- **Category:** `motion_cg`
- **Model:** `LTX-Video 2.5 Distilled GGUF`
- **Resolution:** `1280x720 (16:9 Video @ 24fps)`

```text
0.0s - 1.5s: Extreme close-up on Noey crouching under office desk, soft blue computer glow on her hair, subtle trembling breathing motion, eyes darting up nervously.
1.5s - 3.5s: Slow camera push-in towards her face, heavy blush blooming on cheeks, lips parting with slight nervous exhale, loose strands of caramel brown ponytail swaying softly.
3.5s - 5.0s: Eye contact locked with camera/viewer, subtle embarrassed swallow, dim office light shifting as footsteps pass outside, romantic intimate tension, cinematic 24fps motion blur.
```

### 📌 `pim_motion_ltx`: คุณพิมพ์ (Pim) - Motion CG: Pim HR Archive Confrontation (5s)
- **Category:** `motion_cg`
- **Model:** `LTX-Video 2.5 Distilled GGUF`
- **Resolution:** `1280x720 (16:9 Video @ 24fps)`

```text
0.0s - 2.0s: Low-angle tracking shot along archive filing cabinets towards Pim, shadows slicing across her stern face from window blinds.
2.0s - 3.5s: Hand reaches up in slow motion to adjust red glasses, eyes widening as secret folder slips from fingers.
3.5s - 5.0s: Fast camera push-in on her face, sudden vulnerability shattering her strict composure, rapid shallow breathing, dramatic cinematic lighting shift.
```

### 📌 `rinda_motion_ltx`: คุณรินดา (Rinda) - Motion CG: Rinda Audit Interrogation Motion (5s)
- **Category:** `motion_cg`
- **Model:** `LTX-Video 2.5 Distilled GGUF`
- **Resolution:** `1280x720 (16:9 Video @ 24fps)`

```text
0.0s - 2.0s: Macro shot of fountain pen tapping rhythmically on confidential audit ledger, golden amber desk lamp casting long harsh shadows.
2.0s - 3.5s: Smooth upward pan to Rinda's smirking face leaning forward, amber eyes gleaming with predator-like satisfaction.
3.5s - 5.0s: Slow camera push-in as she leans into whisper range, subtle wisp of breath visible in chilly AC air, cinematic suspense focus.
```

### 📌 `meena_motion_ltx`: คุณมีนา (Meena) - Motion CG: Meena Limousine Night Drive (6s)
- **Category:** `motion_cg`
- **Model:** `LTX-Video 2.5 Distilled GGUF`
- **Resolution:** `1280x720 (16:9 Video @ 24fps)`

```text
0.0s - 2.5s: Interior limousine shot looking out tinted window, neon city lights and rain droplets streaking past in smooth kinetic motion.
2.5s - 4.5s: Camera smoothly tracks left to Meena seated closely, ambient magenta and cyan billboard lighting illuminating her calm hazel eyes.
4.5s - 6.0s: Slow push-in on her face, serene mask dropping as she whispers, lips moving with soft breath, cinematic anamorphic bokeh flare.
```

### 📌 `rhea_motion_ltx`: คุณหนู เร-อา (Rhea) - Motion CG: Rhea Penthouse Storm Climax Motion (6s)
- **Category:** `motion_cg`
- **Model:** `LTX-Video 2.5 Distilled GGUF`
- **Resolution:** `1280x720 (16:9 Video @ 24fps)`

```text
0.0s - 2.0s: Slow low-angle push-in on Rhea seated in executive leather armchair, dark stormy clouds and rain beating against glass behind her, cold icy blue eyes staring calmly.
2.0s - 4.0s: Sudden lightning flash illuminates the room in sharp monochrome, silhouette of her disordered black suit, subtle chest rise and trembling breath revealing vulnerable blush.
4.0s - 6.0s: Camera holds steady in close-up, faint surrender smile touching her lips, rain droplets streaking glass in shallow bokeh, dramatic cinematic anime cutscene.
```

